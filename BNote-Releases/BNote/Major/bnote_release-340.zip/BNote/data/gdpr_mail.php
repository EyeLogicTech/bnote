Guten Tag,<br>
<br>
Im Rahmen unserer Verpflichtung der Datenschutzgrundverordnung (DSGVO) nachzukommen, müssen wir Sie bitten Ihre Daten zu überprüfen und der Verarbeitung zuzustimmen. Sollten Sie uns die Speicherung und Verarbeitung der Daten verweigern, werden wir Ihre personenbezogenen Daten löschen.<br>
<br>
Freundliche Grüße,<br/>
