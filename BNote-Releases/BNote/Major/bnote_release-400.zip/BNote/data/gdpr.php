<h1>Einverständnis</h1>

<p>Hiermit erkläre ich mich bereit folgende personenbezogenen Daten in BNote speichern und verarbeiten zu lassen:</p>

<?php
// read user with the given code
global $system_data;

// show form
$form = new Form("Ihre Daten bei uns", "?mod=gdpr&submit=1");
$form->addHidden("id", $cid);
$form->addHidden("code", $_GET["code"]);
$form->addElement("Vorname", new Field("name", $contact["name"], Field::FIELDTYPE_UNEDITABLE));
$form->addElement("Nachname", new Field("surname", $contact["surname"], Field::FIELDTYPE_UNEDITABLE));

$form->changeSubmitButton("Einverstanden");
$form->write();

?>