sap.ui.controller("bnote.program", {
    
    
    
});