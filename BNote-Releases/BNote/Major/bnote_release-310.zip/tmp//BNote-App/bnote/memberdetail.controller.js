sap.ui.controller("bnote.memberdetail",{	
	
});