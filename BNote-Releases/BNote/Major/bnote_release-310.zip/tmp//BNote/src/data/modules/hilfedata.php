<?php

class HilfeData {
	// dummy
}

?>